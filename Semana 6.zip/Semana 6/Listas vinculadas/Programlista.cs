﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Listas_vinculadas
{
    class Programlista
    {
        static void Main(string[] args)
        {
            Node List = new Node();
            Console.WriteLine("Por favor Inserte los datos de la lista, son 5");
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Inserte el dato {0}", i+1);
                List.insertFirst(Console.ReadLine());
            }
            Console.Clear();
            Console.WriteLine("Los Datos que escribio son:");
            List.imprimir();

            
            Console.WriteLine("\nModifique el dato de la lista");
            List.Modificar();
            Console.WriteLine("\nModificados son:");
            List.imprimir();
            Console.WriteLine("\nAhora borre el dato de la lista");
            List.Borrar();
            Console.WriteLine("\nEl listado ahora queda asi");
            List.imprimir();
            Console.WriteLine("\nPresione cualquier tecla para continuar");
            Console.ReadKey();

        }
    }
}
